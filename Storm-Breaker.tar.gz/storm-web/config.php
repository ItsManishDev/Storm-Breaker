<?php

$CONFIG = array (
    "admin" => [
        "fullname" => "hacker", 
        "password" => "admin",
    ], 
    
);

?>